Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_set_sockets_option("TLS_SNI", "0");

	web_url("katalon-demo-cura.herokuapp.com", 
		"URL=https://katalon-demo-cura.herokuapp.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	lr_think_time(35);

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=14:3F0vefVrAQQsyKnAG85SBqLWhRixAor2kgtKYsY2ucc&cup2hreq=fc7b9e0e13f257d62ac6b50701574a4d81c944b6c7c82adf08fe0ebe7e1260f9", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTTP", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"niikhdgajlphfehepabhhblakbdgeefj\",\"brand\":\"RXQR\",\"cohort\":\"1:1uh3:\",\"cohortname\":\"Auto Main Cohort.\",\"enabled\":true,\"installdate\":6132,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.441f77e6a12317b6133da43ae04862b7d6c848c5789540fc667a227f254dd755\"}]},\"ping\":{\"ping_freshness\":\"{5744399c-6939-4232-ada4-e0bf00e74c21}\",\"rd\":6354},\"updatecheck\":{},\""
		"version\":\"2024.5.24.0\"},{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"RXQR\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{1fe911fa-b291-41e7-a5f7-ac006a9c2c9f}\",\"rd\":6354},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"RXQR\",\"cohort\":\"1:1zdx:\",\"cohortname\":\"4.10.2710.0 to Windows (x86/x64)\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\""
		"ping\":{\"ping_freshness\":\"{a1d9bf21-bd1e-4d1e-a65e-8b8413875089}\",\"rd\":6354},\"updatecheck\":{},\"version\":\"4.10.2710.0\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"RXQR\",\"cohort\":\"1:bm1:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.cd1978742a4afdbaaa15bf712d5c90bef4144caa99024df98f6a9ad58043ae85\"}]},\"ping\":{\"ping_freshness\":\"{d8dee72c-3184-4057-9509-6bba2079e0f8}\",\"rd\":6354},\""
		"updatecheck\":{},\"version\":\"9.49.1\"},{\"accept_locale\":\"ENUS500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"RXQR\",\"cohort\":\"1:s6f:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.40530dd93ad0a5f406a909a50c9aec82f6be28a61208ef052823ff0b59fd3bdd\"}]},\"ping\":{\"ping_freshness\":\"{7f016150-290a-4662-8d2d-a9c90a5e7df3}\",\"rd\":6354},\"updatecheck\":{},\"version\":\"20240404.625479014.14\"},{\""
		"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"RXQR\",\"cohort\":\"1:lwl:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.7c7270ef0b71ec063a98f512831a53690989605dcb0fbf503b95ca5bb4f98b63\"}]},\"ping\":{\"ping_freshness\":\"{bc290d9d-ec77-420a-b1b2-01443f8f30bd}\",\"rd\":6354},\"updatecheck\":{},\"version\":\"448\"},{\"appid\":\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"brand\":\"RXQR\",\"cohort\":\"1:v3l:\",\""
		"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.153e9301be7e862a33e2cab936a0a97e2f8bdf2dae1be516d6fe8a5f184ce028\"}]},\"ping\":{\"ping_freshness\":\"{9de79f3c-3012-4a63-8634-b08c728dcfd6}\",\"rd\":6354},\"updatecheck\":{},\"version\":\"2024.5.3.1\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"RXQR\",\"cohort\":\"1:j5l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\""
		":{\"package\":[{\"fp\":\"1.fd515ec0dc30d25a09641b8b83729234bc50f4511e35ce17d24fd996252eaace\"}]},\"ping\":{\"ping_freshness\":\"{e1868b22-5b36-4ae2-b660-71921820dcca}\",\"rd\":6354},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"RXQR\",\"cohort\":\"1:cux:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.3705656094a72760ea5c7aca9e229b54669c39a219672cfa4d23c3b153fa649c\"}]},\""
		"ping\":{\"ping_freshness\":\"{71920b8e-6c09-43e4-9d55-10649b03dd8d}\",\"rd\":6354},\"updatecheck\":{},\"version\":\"65\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"RXQR\",\"cohort\":\"1:2879:\",\"cohortname\":\"Auto androidlowmem\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.7b206f0a6346ed92d14241d12cbe70fc762e1f1c9485fffa5b90aa45b8783d1d\"}]},\"ping\":{\"ping_freshness\":\"{d2cb16e1-0b41-4fe0-821f-e572cf4b5239}\",\"rd\":6354},"
		"\"updatecheck\":{},\"version\":\"8785\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"RXQR\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.3a118962ef814c91f6476bb9f0de58afa63103af6ac1b8729be9b39a86789e96\"}]},\"ping\":{\"ping_freshness\":\"{a65ccdde-0dd2-4f38-9c96-f599e4880d00}\",\"rd\":6354},\"updatecheck\":{},\"version\":\"1.0.0.15\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\"RXQR\",\"cohort\":"
		"\"1:10zr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{829773cd-8b68-46c8-afdd-5b744f67ec2f}\",\"rd\":6354},\"updatecheck\":{},\"version\":\"1.0.7.1652906823\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"RXQR\",\"cohort\":\"1:ofl:\",\"cohortname\":\"stable64\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\""
		"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{2d5c46f0-08c0-4ed6-8b82-42492da5c9a6}\",\"rd\":6354},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"RXQR\",\"cohort\":\"1:18ql:\",\"cohortname\":\"Auto Stage3\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.25f487750f58c4aae4413367893020f37d6ebf63936eaab497584b84e3f3ced2\"}]},\"ping\":{"
		"\"ping_freshness\":\"{5da8cad2-b931-4b27-9d56-f764292f026c}\",\"rd\":6354},\"updatecheck\":{},\"version\":\"965\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"RXQR\",\"cohort\":\"1:s7x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.888ebbd183d017421d0f23a0a1ea9eaedffefd772878d86c67536c138ef62ada\"}]},\"ping\":{\"ping_freshness\":\"{2bdcb204-27ba-44d2-917a-6880a2099be7}\",\"rd\":6354},\"updatecheck\":{},\""
		"version\":\"3030\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"RXQR\",\"cohort\":\"1:ut9/1a0f/2c99:2c9f@0.5\",\"cohortname\":\"Rollout\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.d1f1a6954babb7330ef005df1b89dcdcb3d163ad1fed7a6800032ebb5d3b8b70\"}]},\"ping\":{\"ping_freshness\":\"{bcbbb2e0-ca31-41bf-9930-512b8be137c7}\",\"rd\":6354},\"updatecheck\":{},\"version\":\"2024.4.15.1148\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc"
		"\",\"brand\":\"RXQR\",\"cohort\":\"1:wvr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.c52c62a7c50daf7d3f73ec16977cd4b0ea401710807d5dbe3850941dd1b73a70\"}]},\"ping\":{\"ping_freshness\":\"{6218bc61-85dc-4ae0-a608-251144774614}\",\"rd\":6354},\"updatecheck\":{},\"version\":\"120.0.6050.0\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"RXQR\",\"cohort\":\"1:w0x:\",\"cohortname\":\"All users\",\"enabled\":true"
		",\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.545666a4efd056351597bb386aea1368105ededc976ed5650d8682daab9f37ff\"}]},\"ping\":{\"ping_freshness\":\"{881c5a11-78d1-47db-99f4-e70ab79ca720}\",\"rd\":6354},\"updatecheck\":{},\"version\":\"3\"},{\"appid\":\"cocncanleafgejenidihemfflagifjic\",\"brand\":\"RXQR\",\"cohort\":\"1:13hr:\",\"cohortname\":\"Everyone Else\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\""
		"1.2b38451531e26ec7b046a0b16da068f362c78c09df795329402ccf77914c18b4\"}]},\"ping\":{\"ping_freshness\":\"{475e0262-843e-4341-a0a8-0ba6740cd472}\",\"rd\":6354},\"updatecheck\":{},\"version\":\"2023.3.30.1305\"},{\"appid\":\"jflhchccmppkfebkiaminageehmchikm\",\"brand\":\"RXQR\",\"cohort\":\"1:26yf:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6153,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.362e7772d3f33014584c77d153634dd0b942e68a7f4b089a8c32c9f1a1dac51a\"}]},\"ping\":{\""
		"ping_freshness\":\"{ceab92d6-b02e-4898-986a-3f49cfe6420f}\",\"rd\":6354},\"updatecheck\":{},\"version\":\"2024.5.23.3\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"RXQR\",\"cohort\":\"1:w59:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}]},\"ping\":{\"ping_freshness\":\"{1170d9ae-82ec-4408-bc32-07cc99c6bb7f}\",\"rd\":6354},\"updatecheck\":{"
		"},\"version\":\"2020.11.2.164946\"},{\"appid\":\"gonpemdgkjcecdgbnaabipppbmgfggbe\",\"brand\":\"RXQR\",\"cohort\":\"1:z1x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.046a7153ace40b4c1fcb2423ffdd0bda38820d2bade6aa5ab6929fe80e4acea3\"}]},\"ping\":{\"ping_freshness\":\"{be6e08be-da78-4c59-9d55-d189bf54cb41}\",\"rd\":6354},\"updatecheck\":{},\"version\":\"2024.5.21.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\""
		":true,\"hw\":{\"avx\":true,\"physmemory\":32,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.17763.5696\"},\"prodversion\":\"125.0.6422.78\",\"protocol\":\"3.1\",\"requestid\":\"{a2ccab07-51af-416b-bd4e-e90dff17ac9d}\",\"sessionid\":\"{59ceffdc-d34a-4d83-b904-695d89e98f72}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\""
		"lastchecked\":0,\"laststarted\":0,\"name\":\"ChromiumUpdater\",\"updatepolicy\":-1,\"version\":\"127.0.6490.0\"},\"updaterversion\":\"125.0.6422.78\"}}", 
		LAST);

	lr_start_transaction("CURA_BookAptnmnt_02_Login");

	web_url("profile.php", 
		"URL=https://katalon-demo-cura.herokuapp.com/profile.php", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://katalon-demo-cura.herokuapp.com/", 
		"Snapshot=t3.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("CURA_BookAptnmnt_02_Login",LR_AUTO);

	lr_start_transaction("CURA_BookAptnmnt_03_EnterCrdClkLogin");

	web_submit_data("authenticate.php", 
		"Action=https://katalon-demo-cura.herokuapp.com/authenticate.php", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://katalon-demo-cura.herokuapp.com/profile.php", 
		"Snapshot=t4.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=username", "Value=John Doe", ENDITEM, 
		"Name=password", "Value=ThisIsNotAPassword", ENDITEM, 
		LAST);

	web_url("ChRDaHJvbWUvMTI1LjAuNjQyMi43OBInCbii4Og8OXPJEgUNYIi74hIFDb7pLjcSBQ0xPZQwIQsdkUemSVVU", 
		"URL=https://content-autofill.googleapis.com/v1/pages/ChRDaHJvbWUvMTI1LjAuNjQyMi43OBInCbii4Og8OXPJEgUNYIi74hIFDb7pLjcSBQ0xPZQwIQsdkUemSVVU?alt=proto", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t5.inf", 
		LAST);

	lr_end_transaction("CURA_BookAptnmnt_03_EnterCrdClkLogin",LR_AUTO);

	lr_think_time(58);

	lr_start_transaction("CURA_BookAPtnmnt_04_EnterDetail_ClkBookAptmnt");

	web_submit_data("appointment.php", 
		"Action=https://katalon-demo-cura.herokuapp.com/appointment.php", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://katalon-demo-cura.herokuapp.com/", 
		"Snapshot=t6.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=facility", "Value=Tokyo CURA Healthcare Center", ENDITEM, 
		"Name=programs", "Value=Medicare", ENDITEM, 
		"Name=visit_date", "Value=25/05/2024", ENDITEM, 
		"Name=comment", "Value=need to have full body checkup", ENDITEM, 
		LAST);

	lr_end_transaction("CURA_BookAPtnmnt_04_EnterDetail_ClkBookAptmnt",LR_AUTO);

	lr_start_transaction("Logout");

	web_url("Logout", 
		"URL=https://katalon-demo-cura.herokuapp.com/authenticate.php?logout", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://katalon-demo-cura.herokuapp.com/appointment.php", 
		"Snapshot=t7.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("Logout",LR_AUTO);

	return 0;
}
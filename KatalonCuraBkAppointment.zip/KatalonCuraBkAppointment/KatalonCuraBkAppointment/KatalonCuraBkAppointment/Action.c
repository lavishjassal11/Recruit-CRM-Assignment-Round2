Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_set_sockets_option("TLS_SNI", "0");
	
	web_reg_find("Text=CURA Healthcare Service" , "SaveCount=LaunchCount" , LAST);
	
	lr_start_transaction("CURA_BookAptnmnt_01_Launch");

	web_url("katalon-demo-cura.herokuapp.com", 
		"URL=https://katalon-demo-cura.herokuapp.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		LAST);

	 if(atoi(lr_eval_string("{LaunchCount}"))==0)
	{
	lr_end_transaction("CURA_BookAptnmnt_01_Launch", LR_FAIL);
	 }
	 else
	 {
	 	lr_end_transaction("CURA_BookAptnmnt_01_Launch", LR_PASS);
	 }

	 lr_think_time(cura_think_time);
	 
	 web_reg_find("Text=Please login to make appointment" , "SaveCount=LoginPgCount" , LAST);
	
	 lr_start_transaction("CURA_BookAptnmnt_02_ClkLoginIcon");

	web_url("profile.php", 
		"URL=https://katalon-demo-cura.herokuapp.com/profile.php", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://katalon-demo-cura.herokuapp.com/", 
		"Snapshot=t3.inf", 
		"Mode=HTTP", 
		LAST);
	 
	  if(atoi(lr_eval_string("{LoginPgCount}"))==0)
	{
		lr_end_transaction("CURA_BookAptnmnt_02_ClkLoginIcon",LR_FAIL);
	  }
	  else
	  {
	  	lr_end_transaction("CURA_BookAptnmnt_02_ClkLoginIcon",LR_PASS);
	  }
	  
	  lr_think_time(cura_think_time);
	 
	 web_reg_find("Text=Make Appointment" , "SaveCount=ClkLoginCount" , LAST);

	lr_start_transaction("CURA_BookAptnmnt_03_EnterCrdClkLogin");

	web_submit_data("authenticate.php", 
		"Action=https://katalon-demo-cura.herokuapp.com/authenticate.php", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://katalon-demo-cura.herokuapp.com/profile.php", 
		"Snapshot=t4.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=username", "Value={p_Username}", ENDITEM, 
		"Name=password", "Value={p_Password}", ENDITEM, 
		LAST);

	if(atoi(lr_eval_string("{ClkLoginCount}"))==0)
	{
		lr_end_transaction("CURA_BookAptnmnt_03_EnterCrdClkLogin",LR_FAIL);
	}
	else
	{
		lr_end_transaction("CURA_BookAptnmnt_03_EnterCrdClkLogin",LR_PASS);
	}
	
	 lr_think_time(cura_think_time);
	 
	web_reg_find("Text=your appointment has been booked" , "SaveCount=ApontmntpgCount" , LAST);
	
	lr_start_transaction("CURA_BookAPtnmnt_04_EnterDetail_ClkBookAptmnt");

	web_submit_data("appointment.php", 
		"Action=https://katalon-demo-cura.herokuapp.com/appointment.php", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://katalon-demo-cura.herokuapp.com/", 
		"Snapshot=t6.inf", 
		"Mode=HTTP", 
		ITEMDATA, 
		"Name=facility", "Value=Tokyo CURA Healthcare Center", ENDITEM, 
		"Name=programs", "Value=Medicare", ENDITEM, 
		"Name=visit_date", "Value={p_VisitDate}", ENDITEM, 
		"Name=comment", "Value=need to have full body checkup", ENDITEM, 
		LAST);

	if(atoi(lr_eval_string("{ApontmntpgCount}"))==0)
	{
	lr_end_transaction("CURA_BookAPtnmnt_04_EnterDetail_ClkBookAptmnt",LR_FAIL);
	}
	else
	{
	lr_end_transaction("CURA_BookAPtnmnt_04_EnterDetail_ClkBookAptmnt",LR_PASS);
	}
	
	 lr_think_time(cura_think_time);
	
	web_reg_find("Text=CURA Healthcare Service" , "SaveCount=LogoutCount" , LAST);
	
	lr_start_transaction("Logout");

	web_url("Logout", 
		"URL=https://katalon-demo-cura.herokuapp.com/authenticate.php?logout", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://katalon-demo-cura.herokuapp.com/appointment.php", 
		"Snapshot=t7.inf", 
		"Mode=HTTP", 
		LAST);

	 if(atoi(lr_eval_string("{LogoutCount}"))==0)
	{
	 	lr_end_transaction("Logout",LR_FAIL);
	 }
	 else{
	 	lr_end_transaction("Logout",LR_PASS);
	 }
	return 0;
}
Action()
{
	web_set_max_html_param_len("99999");
	
	web_set_sockets_option("SSL_VERSION", "AUTO");
	
	web_cleanup_cookies();
	web_cache_cleanup();
	
	//link href="template.css;jsessionid=683F244FA159A1DBD11D425E5966BD37

	web_reg_save_param_ex(
		"ParamName=c_JSessionID",
		"LB=link href=\"template.css;jsessionid=",
		"RB=\" rel",
		SEARCH_FILTERS,
		"Scope=BODY",
		LAST);
	
	lr_start_transaction("ParaBank_01_Launch");

	web_reg_find("Text=Customer Login" , "SaveCount=LaunchCount" , LAST);
	
	web_url("index.htm", 
		"URL=https://parabank.parasoft.com/parabank/index.htm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTTP", 
		LAST);


	web_url("template.css;jsessionid={c_JSessionID}", 
		"URL=https://parabank.parasoft.com/parabank/template.css;jsessionid={c_JSessionID}", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t3.inf", 
		LAST);

	web_url("style.css;jsessionid={c_JSessionID}", 
		"URL=https://parabank.parasoft.com/parabank/style.css;jsessionid={c_JSessionID}", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t4.inf", 
		LAST);

	web_url("jquery.min.js;jsessionid={c_JSessionID}", 
		"URL=https://parabank.parasoft.com/parabank/webjars/jquery/3.7.1/jquery.min.js;jsessionid={c_JSessionID}", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t5.inf", 
		LAST);

	web_url("logo.gif;jsessionid={c_JSessionID}", 
		"URL=https://parabank.parasoft.com/parabank/images/logo.gif;jsessionid={c_JSessionID}", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t6.inf", 
		LAST);

	web_url("clear.gif;jsessionid={c_JSessionID}", 
		"URL=https://parabank.parasoft.com/parabank/images/clear.gif;jsessionid={c_JSessionID}", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t7.inf", 
		LAST);


	web_url("header-main.jpg;jsessionid={c_JSessionID}", 
		"URL=https://parabank.parasoft.com/parabank/images/header-main.jpg;jsessionid={c_JSessionID}", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t8.inf", 
		LAST);
	
 if(atoi(lr_eval_string("{LaunchCount}"))==0)
	{
	lr_end_transaction("ParaBank_01_Launch", LR_FAIL);
 }
	else	
	{
		lr_end_transaction("ParaBank_01_Launch", LR_PASS);
	}

	lr_think_time(para_think_time);
	
	lr_start_transaction("ParaBank_AccountCreate_02_RegisterButton");

	web_url("register.htm;jsessionid={c_JSessionID}", 
		"URL=https://parabank.parasoft.com/parabank/register.htm;jsessionid={c_JSessionID}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t10.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("ParaBank_AccountCreate_02_RegisterButton",LR_PASS);

	lr_think_time(para_think_time);
	
	lr_start_transaction("ParaBank_AccountCreate_03_RegisterCustomer");


	web_reg_find("Text=our account was created successfully" , "SaveCount=CreateAccCount" , LAST);

	//h1 class="title">Welcome lavishjassal2</h1>

	web_reg_save_param_ex(
		"ParamName=c_Username",
		"LB=h1 class=\"title\">Welcome ",
		"RB=</h1>",
		SEARCH_FILTERS,
		"Scope=BODY",
		LAST);
	
	web_submit_data("register.htm", 
		"Action=https://parabank.parasoft.com/parabank/register.htm", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://parabank.parasoft.com/parabank/register.htm;jsessionid={c_JSessionID}", 
		"Snapshot=t11.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=customer.firstName", "Value={p_FirstName}vi", ENDITEM, 
		"Name=customer.lastName", "Value=kum{p_Lastname}", ENDITEM, 
		"Name=customer.address.street", "Value=Hn095{p_Hno}8 street new", ENDITEM, 
		"Name=customer.address.city", "Value=Shahkot", ENDITEM, 
		"Name=customer.address.state", "Value=Punjab", ENDITEM, 
		"Name=customer.address.zipCode", "Value=144702", ENDITEM, 
		"Name=customer.phoneNumber", "Value=735{p_mobilenum}10", ENDITEM, 
		"Name=customer.ssn", "Value={p_SSNNum}4848", ENDITEM, 
		"Name=customer.username", "Value=lavishjassal{p_Username}", ENDITEM, 
		"Name=customer.password", "Value=L@vish123", ENDITEM, 
		"Name=repeatedPassword", "Value=L@vish123", ENDITEM, 
		LAST);

	web_url("header-customer.jpg", 
		"URL=https://parabank.parasoft.com/parabank/images/header-customer.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://parabank.parasoft.com/parabank/register.htm", 
		"Snapshot=t12.inf", 
		LAST);

 if(atoi(lr_eval_string("{CreateAccCount}"))==0)
	{
	lr_end_transaction("ParaBank_AccountCreate_03_RegisterCustomer",LR_FAIL);
  }
  else
  {
 	lr_end_transaction("ParaBank_AccountCreate_03_RegisterCustomer",LR_PASS);
  }
	lr_think_time(para_think_time);
	
	web_reg_find("Text=Customer Login" , "SaveCount=LogoutCount" , LAST);
		
	lr_start_transaction("ParaBank_AccountCreate_04_Logout");

	web_url("logout.htm", 
		"URL=https://parabank.parasoft.com/parabank/logout.htm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://parabank.parasoft.com/parabank/register.htm", 
		"Snapshot=t25.inf", 
		"Mode=HTTP", 
		LAST);
	
	if(atoi(lr_eval_string("{LogoutCount}"))==0)
	{
	lr_end_transaction("ParaBank_AccountCreate_04_Logout",LR_FAIL);
	}
	else
	{
		lr_end_transaction("ParaBank_AccountCreate_04_Logout",LR_PASS);
	}
	/*
	strcpy(buff, lr_eval_string("{c_Username}"));
    fd=fopen("D:\\Lavish\\Testing\\CRM\\Completed\\24.06\\CreateBI.txt","a");
    fprintf(fd,"%s\n", buff);
    fclose(fd); 
*/
	return 0;
}
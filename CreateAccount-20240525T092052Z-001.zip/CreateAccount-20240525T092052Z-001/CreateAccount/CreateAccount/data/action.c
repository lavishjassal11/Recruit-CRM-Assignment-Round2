Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("AEC=AQTF6HzYwtj-K68NBR1Cd6NSkxfTnj6RXspaqKZToFmN99TnrfK4n1Uux38; DOMAIN=accounts.google.com");

	web_add_cookie("NID=514=d81onyHGVVzZZ7sLx5xnb4rEXFkABm1_sy3rg909BBb_q06xaq_EpnnjzASpDY7Y5NphVLSgtOp9EEwW822qXFt4IhM9ZLoGwRktPxDR-gnNH94E5PaX8gvAivxDkrzMc1DvFITs-4lGmT7vMqzF_AQoI8yVfEbdAqpfrpTBXhyUQupzEolgFDQfTgky5oA5TS0PvJPptg; DOMAIN=accounts.google.com");

	web_custom_request("ListAccounts", 
		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		"Body= ", 
		LAST);

	web_url("index.htm", 
		"URL=https://parabank.parasoft.com/parabank/index.htm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_start(NULL);

	web_url("template.css;jsessionid=683F244FA159A1DBD11D425E5966BD37", 
		"URL=https://parabank.parasoft.com/parabank/template.css;jsessionid=683F244FA159A1DBD11D425E5966BD37", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t3.inf", 
		LAST);

	web_url("style.css;jsessionid=683F244FA159A1DBD11D425E5966BD37", 
		"URL=https://parabank.parasoft.com/parabank/style.css;jsessionid=683F244FA159A1DBD11D425E5966BD37", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t4.inf", 
		LAST);

	web_url("jquery.min.js;jsessionid=683F244FA159A1DBD11D425E5966BD37", 
		"URL=https://parabank.parasoft.com/parabank/webjars/jquery/3.7.1/jquery.min.js;jsessionid=683F244FA159A1DBD11D425E5966BD37", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t5.inf", 
		LAST);

	web_url("logo.gif;jsessionid=683F244FA159A1DBD11D425E5966BD37", 
		"URL=https://parabank.parasoft.com/parabank/images/logo.gif;jsessionid=683F244FA159A1DBD11D425E5966BD37", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t6.inf", 
		LAST);

	web_url("clear.gif;jsessionid=683F244FA159A1DBD11D425E5966BD37", 
		"URL=https://parabank.parasoft.com/parabank/images/clear.gif;jsessionid=683F244FA159A1DBD11D425E5966BD37", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t7.inf", 
		LAST);

	web_concurrent_end(NULL);

	lr_think_time(9);

	web_url("header-main.jpg;jsessionid=683F244FA159A1DBD11D425E5966BD37", 
		"URL=https://parabank.parasoft.com/parabank/images/header-main.jpg;jsessionid=683F244FA159A1DBD11D425E5966BD37", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t8.inf", 
		LAST);

	lr_think_time(32);

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=14:6osrzyM5145El_tCW1toa38e1NAx5hJe1V9YBtjedN4&cup2hreq=d6ccdc3ca1afce05d4c390f672a68537387deb8a771a49cc6b903eefeea3f92d", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t9.inf", 
		"Mode=HTTP", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"niikhdgajlphfehepabhhblakbdgeefj\",\"brand\":\"RXQR\",\"cohort\":\"1:1uh3:\",\"cohortname\":\"Auto Main Cohort.\",\"enabled\":true,\"installdate\":6132,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.441f77e6a12317b6133da43ae04862b7d6c848c5789540fc667a227f254dd755\"}]},\"ping\":{\"ping_freshness\":\"{5eeb03a8-8c27-4486-a50e-7c43c39a6d9d}\",\"rd\":6353},\"updatecheck\":{},\""
		"version\":\"2024.5.24.0\"},{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"RXQR\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{6092aa78-2b2d-496f-ab52-efc639ad2f7c}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"RXQR\",\"cohort\":\"1:1zdx:\",\"cohortname\":\"4.10.2710.0 to Windows (x86/x64)\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\""
		"ping\":{\"ping_freshness\":\"{694ad3c3-1e6c-4feb-952d-563cc9a0b624}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"4.10.2710.0\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"RXQR\",\"cohort\":\"1:bm1:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.cd1978742a4afdbaaa15bf712d5c90bef4144caa99024df98f6a9ad58043ae85\"}]},\"ping\":{\"ping_freshness\":\"{b84c9c8e-672c-471f-ae2f-7ca9bd4d1c35}\",\"rd\":6353},\""
		"updatecheck\":{},\"version\":\"9.49.1\"},{\"accept_locale\":\"ENUS500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"RXQR\",\"cohort\":\"1:s6f:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.40530dd93ad0a5f406a909a50c9aec82f6be28a61208ef052823ff0b59fd3bdd\"}]},\"ping\":{\"ping_freshness\":\"{0ad8b250-25b1-44eb-8309-e3c93d67b68d}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"20240404.625479014.14\"},{\""
		"appid\":\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"brand\":\"RXQR\",\"cohort\":\"1:v3l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.153e9301be7e862a33e2cab936a0a97e2f8bdf2dae1be516d6fe8a5f184ce028\"}]},\"ping\":{\"ping_freshness\":\"{bdd53559-5a79-4875-aef5-5a7bd8e50e3b}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"2024.5.3.1\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"RXQR\",\"cohort\":\"1:j5l:\",\""
		"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.fd515ec0dc30d25a09641b8b83729234bc50f4511e35ce17d24fd996252eaace\"}]},\"ping\":{\"ping_freshness\":\"{3909c5ce-84d2-4d52-84d0-c1d311de6369}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"RXQR\",\"cohort\":\"1:cux:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\""
		"package\":[{\"fp\":\"1.3705656094a72760ea5c7aca9e229b54669c39a219672cfa4d23c3b153fa649c\"}]},\"ping\":{\"ping_freshness\":\"{c6d9fb0b-c740-4100-ba40-2fc84b904e4a}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"65\"},{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"RXQR\",\"cohort\":\"1:lwl:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.7c7270ef0b71ec063a98f512831a53690989605dcb0fbf503b95ca5bb4f98b63\"}]},\""
		"ping\":{\"ping_freshness\":\"{8bfc0921-ae00-4ad7-afc6-c24e5fc8050b}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"448\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"RXQR\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.3a118962ef814c91f6476bb9f0de58afa63103af6ac1b8729be9b39a86789e96\"}]},\"ping\":{\"ping_freshness\":\"{2e97b51a-df30-4e73-8c78-1cdd3441bbb3}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"1.0.0.15"
		"\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"RXQR\",\"cohort\":\"1:ofl:\",\"cohortname\":\"stable64\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{bc130d2d-afaf-4b5a-9359-1d433c52565d}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"RXQR\",\"cohort\":\"1"
		":ut9/1a0f/2c99:2c9f@0.5\",\"cohortname\":\"Rollout\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.d1f1a6954babb7330ef005df1b89dcdcb3d163ad1fed7a6800032ebb5d3b8b70\"}]},\"ping\":{\"ping_freshness\":\"{d07cc379-dc87-49e8-ad16-f5096d81078d}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"2024.4.15.1148\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"RXQR\",\"cohort\":\"1:wvr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\""
		":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.c52c62a7c50daf7d3f73ec16977cd4b0ea401710807d5dbe3850941dd1b73a70\"}]},\"ping\":{\"ping_freshness\":\"{47e49372-f6a9-49a9-83e3-a3da57f6794f}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"120.0.6050.0\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"RXQR\",\"cohort\":\"1:18ql:\",\"cohortname\":\"Auto Stage3\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\""
		"1.25f487750f58c4aae4413367893020f37d6ebf63936eaab497584b84e3f3ced2\"}]},\"ping\":{\"ping_freshness\":\"{b2d77348-6b6d-447d-916b-278624f4f44f}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"965\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"RXQR\",\"cohort\":\"1:w0x:\",\"cohortname\":\"All users\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.545666a4efd056351597bb386aea1368105ededc976ed5650d8682daab9f37ff\"}]},\"ping\":{\""
		"ping_freshness\":\"{56dcddc2-4622-4ff1-ab75-3e5fd8a7e662}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"3\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"RXQR\",\"cohort\":\"1:s7x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.888ebbd183d017421d0f23a0a1ea9eaedffefd772878d86c67536c138ef62ada\"}]},\"ping\":{\"ping_freshness\":\"{bdd04e15-895b-49d5-b360-6ce2395befec}\",\"rd\":6353},\"updatecheck\":{},\""
		"version\":\"3030\"},{\"appid\":\"cocncanleafgejenidihemfflagifjic\",\"brand\":\"RXQR\",\"cohort\":\"1:13hr:\",\"cohortname\":\"Everyone Else\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.2b38451531e26ec7b046a0b16da068f362c78c09df795329402ccf77914c18b4\"}]},\"ping\":{\"ping_freshness\":\"{00a78cfa-7aea-4668-b324-ef8a99bcaed2}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"2023.3.30.1305\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\""
		":\"RXQR\",\"cohort\":\"1:2879:\",\"cohortname\":\"Auto androidlowmem\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.9123eaa5004d617de29fbc6e0208b8ae20faa533fd8ce9060915832f6a1bb799\"}]},\"ping\":{\"ping_freshness\":\"{942ea2a2-d109-443d-8d70-bfa28af7c73e}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"8784\"},{\"appid\":\"jflhchccmppkfebkiaminageehmchikm\",\"brand\":\"RXQR\",\"cohort\":\"1:26yf:\",\"cohortname\":\"Stable\",\"enabled\":true,\""
		"installdate\":6153,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.362e7772d3f33014584c77d153634dd0b942e68a7f4b089a8c32c9f1a1dac51a\"}]},\"ping\":{\"ping_freshness\":\"{5ab767bd-47c3-4cf7-a486-2e0dc47e13ac}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"2024.5.23.3\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\"RXQR\",\"cohort\":\"1:10zr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\""
		"{85abd5a4-76b2-4ef9-a719-5bd883a32dbc}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"1.0.7.1652906823\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"RXQR\",\"cohort\":\"1:w59:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}]},\"ping\":{\"ping_freshness\":\"{4a61ba22-ab5a-4a69-bd84-4d3b6d2b90ee}\",\"rd\":6353},\"updatecheck\":{},\"version\""
		":\"2020.11.2.164946\"},{\"appid\":\"gonpemdgkjcecdgbnaabipppbmgfggbe\",\"brand\":\"RXQR\",\"cohort\":\"1:z1x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.046a7153ace40b4c1fcb2423ffdd0bda38820d2bade6aa5ab6929fe80e4acea3\"}]},\"ping\":{\"ping_freshness\":\"{87b9c307-d33d-47c0-8711-f3c90612cf68}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"2024.5.21.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":true,\"hw\":{\""
		"avx\":true,\"physmemory\":32,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.17763.5696\"},\"prodversion\":\"125.0.6422.78\",\"protocol\":\"3.1\",\"requestid\":\"{13d6cc1a-779e-48bb-9540-80ebae102da3}\",\"sessionid\":\"{3fdedaff-b448-4be2-8f95-1ff99b7aa7f7}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\""
		"laststarted\":0,\"name\":\"ChromiumUpdater\",\"updatepolicy\":-1,\"version\":\"127.0.6490.0\"},\"updaterversion\":\"125.0.6422.78\"}}", 
		LAST);

	lr_think_time(33);

	lr_start_transaction("ParaBank_AccountCreate_02_Register");

	web_url("register.htm;jsessionid=683F244FA159A1DBD11D425E5966BD37", 
		"URL=https://parabank.parasoft.com/parabank/register.htm;jsessionid=683F244FA159A1DBD11D425E5966BD37", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t10.inf", 
		"Mode=HTTP", 
		LAST);

	lr_think_time(78);

	web_submit_data("register.htm", 
		"Action=https://parabank.parasoft.com/parabank/register.htm", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://parabank.parasoft.com/parabank/register.htm;jsessionid=683F244FA159A1DBD11D425E5966BD37", 
		"Snapshot=t11.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=customer.firstName", "Value=lavi", ENDITEM, 
		"Name=customer.lastName", "Value=kumar", ENDITEM, 
		"Name=customer.address.street", "Value=Hn09584848 street new", ENDITEM, 
		"Name=customer.address.city", "Value=Shahkot", ENDITEM, 
		"Name=customer.address.state", "Value=Punjab", ENDITEM, 
		"Name=customer.address.zipCode", "Value=144702", ENDITEM, 
		"Name=customer.phoneNumber", "Value=7355919010", ENDITEM, 
		"Name=customer.ssn", "Value=29384848", ENDITEM, 
		"Name=customer.username", "Value=lavishjassal2", ENDITEM, 
		"Name=customer.password", "Value=L@vish123", ENDITEM, 
		"Name=repeatedPassword", "Value=L@vish123", ENDITEM, 
		LAST);

	web_url("header-customer.jpg", 
		"URL=https://parabank.parasoft.com/parabank/images/header-customer.jpg", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://parabank.parasoft.com/parabank/register.htm", 
		"Snapshot=t12.inf", 
		LAST);

	web_custom_request("google-ohttp-relay-safebrowsing.fastly-edge.com", 
		"URL=https://google-ohttp-relay-safebrowsing.fastly-edge.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=message/ohttp-res", 
		"Referer=", 
		"Snapshot=t13.inf", 
		"Mode=HTTP", 
		"EncType=message/ohttp-req", 
		"BodyBinary=\\x08\\x00 \\x00\\x01\\x00\\x02C\\x81\\xD2\\xDB~%P\\xECF-i\\xCA\\xBA\\xEF\\x11\\xD7'\\xDA\\xB516y\\xBD\\xD1\\xC0\\xB2-\\xEA\\xD0k\\xA4:\\xFB\\xD8\\xC3\\x87\\xAA\t\\xF8\\xF6\\xB0V\\xFB\\x00\\xBB4_\\x18\\x10\\xCB\\x14e\\xCB\\xBB\\x1F\\xDD\\xCA\\xBF\\xDB\\xE8J\\x86\\xF1\\xBC\\xA4\\xC2\\x7F\\x9C\\xCD\\x82A\\xF1\\x83\\x17)\\x8C\\xC4\\xA0\\x13\\xC0\\x93J\\x94!\\xBAj\\xC0\\x18\\xE4MMH\\xD3E6\\x04U\\xCBY\\xB8\\xB3\\x9C\\xC4\\x9E^\\xDC\\xA8\\xCD\\xD6}\\x1D\\x0E\\xD4\\xDF\\x18\\xAE>\\xC4C8\\x1Di"
		">or\\xBE\\xCC\\xC9E\\x83Y=\\x16\\xFF\\xC8\\x86\\xF0\\xBB\\x05\r\\x84\\xBE\\xD3\\xEF\\xD3x=\\xC6\\xF5\\xEF\\x0F\\xCAS\\xF5oow\\x0CE\\x8F~x\\xB6-\\x90*\\xA1\\\\h\\xA8z=\\xA2\\x16\\x06a\\x1Ao/\\x82H\\xAB\\xA4\\xDAw\\x17!_sr~@\\xA9A2\\xC7\\xA1\\x03\\x8C\\xA2<\\x1F\\x06\\xCFh{\\x82\\xE8\\xE1\\x94<\\xF6:\\x10\\x03\\xC9^^\\x85\\x88)+\\xBB\\x9D\\x06\\xB4\\xD39\\x9EX\\xECU5s\\xAB\\x87\\xDC3k\\x97%\\x8E\\xFE\\xC7]&X\\xD3\\xB8|F3\\xEF^l0\\xFB\\x8A\\xDB\\xEB\\x07\\xADg6}L\\xCB\\xE4|\\xAFl\\xF0A\\xEDJ", 
		LAST);

	web_custom_request("leaks_lookupSingle", 
		"URL=https://passwordsleakcheck-pa.googleapis.com/v1/leaks_lookupSingle", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/x-protobuf", 
		"Referer=", 
		"Snapshot=t14.inf", 
		"Mode=HTTP", 
		"EncType=application/x-protobuf", 
		"BodyBinary=\n\\x04\\xAC\\xD2\\xDB@\\x10\\x1A\\x1A!\\x02\\xC1\\x03c\\x0C\\x9F\\xED\\x87\\x9A\\x8C\\x95\\xCC\\x9A*\\xF3,\\x97\\xA2\\xB1\\xDD\\xB7\\xD8?\\xEA\\xFD\\xAC|G\\xBE\\x83\\xFD\\x87\\xFF \\x05", 
		LAST);

	lr_end_transaction("ParaBank_AccountCreate_02_Register",LR_AUTO);

	lr_think_time(67);

	lr_start_transaction("ParaBank_AccountCreation_03_AccountOVerView");

	web_url("overview.htm", 
		"URL=https://parabank.parasoft.com/parabank/overview.htm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://parabank.parasoft.com/parabank/register.htm", 
		"Snapshot=t15.inf", 
		"Mode=HTTP", 
		LAST);

	lr_end_transaction("ParaBank_AccountCreation_03_AccountOVerView",LR_AUTO);

	return 0;
}
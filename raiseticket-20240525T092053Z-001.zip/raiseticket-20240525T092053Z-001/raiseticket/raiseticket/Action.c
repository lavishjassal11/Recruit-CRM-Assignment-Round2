Action()
{

	web_set_max_html_param_len("99999");
	
	web_set_sockets_option("SSL_VERSION", "AUTO");
	
	web_cleanup_cookies();
	web_cache_cleanup();
	
	//link href="template.css;jsessionid=70C095D2641C8FE0916F16E37DB2EB78

	web_reg_save_param_ex(
		"ParamName=c_JSessionID",
		"LB=link href=\"template.css;jsessionid=",
		"RB=\" rel",
		SEARCH_FILTERS,
		"Scope=BODY",
		LAST);
	
	lr_start_transaction("ParaBank_01_Launch");

	web_reg_find("Text=Customer Login" , "SaveCount=LaunchCount" , LAST);
	
	web_url("index.htm", 
		"URL=https://parabank.parasoft.com/parabank/index.htm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTTP", 
		LAST);


	web_url("template.css;jsessionid={c_JSessionID}", 
		"URL=https://parabank.parasoft.com/parabank/template.css;jsessionid={c_JSessionID}", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t3.inf", 
		LAST);

	web_url("style.css;jsessionid={c_JSessionID}", 
		"URL=https://parabank.parasoft.com/parabank/style.css;jsessionid={c_JSessionID}", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t4.inf", 
		LAST);

	web_url("jquery.min.js;jsessionid={c_JSessionID}", 
		"URL=https://parabank.parasoft.com/parabank/webjars/jquery/3.7.1/jquery.min.js;jsessionid={c_JSessionID}", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t5.inf", 
		LAST);

	web_url("logo.gif;jsessionid={c_JSessionID}", 
		"URL=https://parabank.parasoft.com/parabank/images/logo.gif;jsessionid={c_JSessionID}", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t6.inf", 
		LAST);

	web_url("clear.gif;jsessionid={c_JSessionID}", 
		"URL=https://parabank.parasoft.com/parabank/images/clear.gif;jsessionid={c_JSessionID}", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t7.inf", 
		LAST);


	web_url("header-main.jpg;jsessionid={c_JSessionID}", 
		"URL=https://parabank.parasoft.com/parabank/images/header-main.jpg;jsessionid={c_JSessionID}", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t8.inf", 
		LAST);
	
 if(atoi(lr_eval_string("{LaunchCount}"))==0)
	{
	lr_end_transaction("ParaBank_01_Launch", LR_FAIL);
 }
	else	
	{
		lr_end_transaction("ParaBank_01_Launch", LR_PASS);
	}

	lr_think_time(para_think_time);
	
	
	web_reg_find("Text=Customer Care" , "SaveCount=SupportCount" , LAST);
	
	lr_start_transaction("ParaBank_RaiseTicket_01_ClickSupportIcon");

	web_url("contact", 
		"URL=https://parabank.parasoft.com/parabank/contact.htm;jsessionid={c_JSessionID}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t11.inf", 
		"Mode=HTTP", 
		LAST);
	
	if(atoi(lr_eval_string("{SupportCount}"))==0)
	{
	lr_end_transaction("ParaBank_RaiseTicket_01_ClickSupportIcon",LR_FAIL);
	}
	else
	{
		lr_end_transaction("ParaBank_RaiseTicket_01_ClickSupportIcon",LR_PASS);
	}

	lr_think_time(para_think_time);
	
	
	web_reg_find("Text=A Customer Care Representative will be contacting you" , "SaveCount=SendToCustSptCount" , LAST);
	
	lr_start_transaction("ParBank_RaiseTicket_02_EnterDetail_SendToCustSpt");

	web_submit_data("contact.htm", 
		"Action=https://parabank.parasoft.com/parabank/contact.htm", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://parabank.parasoft.com/parabank/contact.htm;jsessionid={c_JSessionID}", 
		"Snapshot=t15.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=name", "Value=lavishjassal{p_Name}", ENDITEM, 
		"Name=email", "Value=lavish{p_Email}@gmail.com", ENDITEM, 
		"Name=phone", "Value={p_MobNum}819010", ENDITEM, 
		"Name=message", "Value=website crashing intermittently", ENDITEM, 
		LAST);
	
	if(atoi(lr_eval_string("{SendToCustSptCount}"))==0)
	{
	lr_end_transaction("ParBank_RaiseTicket_02_EnterDetail_SendToCustSpt",LR_FAIL);
	}
	else
	{
		lr_end_transaction("ParBank_RaiseTicket_02_EnterDetail_SendToCustSpt",LR_PASS);
	}
	return 0;
}
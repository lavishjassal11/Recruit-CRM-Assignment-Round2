Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=125", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		LAST);

	web_add_cookie("AEC=AQTF6HzYwtj-K68NBR1Cd6NSkxfTnj6RXspaqKZToFmN99TnrfK4n1Uux38; DOMAIN=accounts.google.com");

	web_add_cookie("NID=514=mqhFrdh27m9IcuF0qjA461Ud4O0gqvAQXYMsoeBf_2uFMYuNo6Sk0qja8weVLCc0U4VUKF0iaf7k0Snr8ghq14BTiIu-Z7UpZ5SZgOT2vgpYNDMmZPjt5g7j-OTXoCExUp1E9NJvtnAC0nNhb56jmO0U9jiKeN5Nrv6N2J0X7THggPcSBt5JxRuA-1EQ7lcRcpTGU1JVsA; DOMAIN=accounts.google.com");

	web_custom_request("ListAccounts", 
		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTTP", 
		"Body= ", 
		LAST);

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=14:Dk7kFo61twtFsuHey3zhQi4-OSx5_8tx6ILp02kZ4F0&cup2hreq=2ce61de4c79e180d727d716d69716ee2f9dde0c4bc854697deb276d97c73c603", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTTP", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chromecrx\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"ghbmnnjooekpmoecnnnilnnbdlolhkhi\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":6077,\"installedby\":\"external\",\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.378723490592c0627ac18a287f9a9cb74970c3c6e10a177c322282bfc1d01e01\"}]},\"ping\":{\"ping_freshness\":\"{85525123-e0e0-4901-a5ac-8dac3594d766}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"1.75.4\"},{\"appid\""
		":\"nmmhkkegccagdldgiimedpiccmgmieda\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":6077,\"installedby\":\"other\",\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"2.1.0.0.6\"}]},\"ping\":{\"ping_freshness\":\"{b5c8df13-a4c0-4908-a677-07f2e4924f2b}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"1.0.0.6\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":true,\"hw\":{\"avx\":true,\"physmemory\":32,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true"
		"},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.17763.5696\"},\"prodversion\":\"125.0.6422.78\",\"protocol\":\"3.1\",\"requestid\":\"{5005d752-6d56-48d3-a2a0-ccdcfcf2eb9b}\",\"sessionid\":\"{acbe9e00-4d6f-41c0-a12e-7c761a3bf807}\",\"updaterversion\":\"125.0.6422.78\"}}", 
		LAST);

	web_url("index.htm", 
		"URL=https://parabank.parasoft.com/parabank/index.htm", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTTP", 
		LAST);

	web_concurrent_start(NULL);

	web_url("template.css;jsessionid=70C095D2641C8FE0916F16E37DB2EB78", 
		"URL=https://parabank.parasoft.com/parabank/template.css;jsessionid=70C095D2641C8FE0916F16E37DB2EB78", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t5.inf", 
		LAST);

	web_url("jquery.min.js;jsessionid=70C095D2641C8FE0916F16E37DB2EB78", 
		"URL=https://parabank.parasoft.com/parabank/webjars/jquery/3.7.1/jquery.min.js;jsessionid=70C095D2641C8FE0916F16E37DB2EB78", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t6.inf", 
		LAST);

	web_url("clear.gif;jsessionid=70C095D2641C8FE0916F16E37DB2EB78", 
		"URL=https://parabank.parasoft.com/parabank/images/clear.gif;jsessionid=70C095D2641C8FE0916F16E37DB2EB78", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t7.inf", 
		LAST);

	web_url("style.css;jsessionid=70C095D2641C8FE0916F16E37DB2EB78", 
		"URL=https://parabank.parasoft.com/parabank/style.css;jsessionid=70C095D2641C8FE0916F16E37DB2EB78", 
		"Resource=1", 
		"RecContentType=text/css", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t8.inf", 
		LAST);

	web_url("logo.gif;jsessionid=70C095D2641C8FE0916F16E37DB2EB78", 
		"URL=https://parabank.parasoft.com/parabank/images/logo.gif;jsessionid=70C095D2641C8FE0916F16E37DB2EB78", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t9.inf", 
		LAST);

	web_concurrent_end(NULL);

	web_url("header-main.jpg;jsessionid=70C095D2641C8FE0916F16E37DB2EB78", 
		"URL=https://parabank.parasoft.com/parabank/images/header-main.jpg;jsessionid=70C095D2641C8FE0916F16E37DB2EB78", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t10.inf", 
		LAST);

	lr_think_time(27);

	lr_start_transaction("ParaBank_RaiseTicket_01_ClickSupportIcon");

	web_url("contact", 
		"URL=https://parabank.parasoft.com/parabank/contact.htm;jsessionid=70C095D2641C8FE0916F16E37DB2EB78", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://parabank.parasoft.com/parabank/index.htm", 
		"Snapshot=t11.inf", 
		"Mode=HTTP", 
		LAST);

	web_custom_request("google-ohttp-relay-safebrowsing.fastly-edge.com", 
		"URL=https://google-ohttp-relay-safebrowsing.fastly-edge.com/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=message/ohttp-res", 
		"Referer=", 
		"Snapshot=t12.inf", 
		"Mode=HTTP", 
		"EncType=message/ohttp-req", 
		"BodyBinary=\t\\x00 \\x00\\x01\\x00\\x02Gz.P}\\x80MJH*n\\x06\\xBE\\x9D%\\x12E\\xA4Y\\xC4e\\x07j\\xFB\\x01\\x83\\xB3^\\xB3\\xF1\\xF9\\x1A\\x98\\xE9R\\x15=\\x89-\\xDC\\xD1\\xFD\\xBE\\xEB=C\\xD2\\xDFb\\x939\\xBFO\\x8A\\xA5\\xA5#\\xC9=f\\xE4\\xCF\\xFB\\xD2\\x82pWpH\\xEF\\x01\\xF3\\x10N\\x10\\x7F\\xDB\\x9AwVUo\\xDF\\xCFL\\xE0\\x88\\xBC\\x17\\xD4\\x9Dr\\x01\\xC1\\xAC\\xEC\\x1F\t\\xB2G\\xDE^\\xC3\\x1E\\xB5\\x0E\\xA2\\xA0I\\x8B\\x81\\x05\\\\\\xE6\\x93\\x00U\\xBD\\xBD\\xEAD\\x7F\\xBC,"
		"\\x18M\\x80\\x89\\xE2\\x89\\x96\\x9EFaL\\x9E\\x9C\\xE3A\t\\xB2\\x18>\\xC6\\xAB\\x1B\\x8D\\xB2\\xE4,\\xA7\\xF7\\x02\\x9A \\xFE\\xB5\\x928\\xD7\\xC1\\xB6\\xADBs\\x10 \\x12\\xFDWt-\\x1C\\x08\\x10w\\x8F\\xEA\\xC0\\x8E|G\\xE2d\\x18\\xCE\\x17z\\x16\r\\x8A\\xEF\\x01\\xB6\\x9F:\\xBA\\xAA\\x81-\\xF7\\xA7\\x16>`\\xE8k\\x1C8\\xD5/\\xC1\\\\\\xB6\\xBD\\x0F\\x12\\x1DG&\\x18\\xD7A\\xCB%\\xA3\\xD04\nD\r&\\xC7\\xE0b\\xA1\\xAA\\x11\\x86\\xBBX\\x9BS\\xFD\\xB5\\xD7\\xEB1\\x9B\\xF2`\\\\u\\x8F\\x92l\n"
		"\\x1B\\xFC\\xCC\\xF2\\xEC\\xCB\to\\xE8\\xF4\\xDEJ}\\x0C%\\x84(\\xD7", 
		LAST);

	lr_end_transaction("ParaBank_RaiseTicket_01_ClickSupportIcon",LR_AUTO);

	lr_think_time(8);

	web_custom_request("json_2", 
		"URL=http://update.googleapis.com/service/update2/json?cup2key=14:-XsCzPqA9sFsxYO2Upe0y5epoesQfRtiRJQe9n_0xQw&cup2hreq=77d42eb1a1dac7ef3c80bbfd43c0f1aa82bdd0b0f4dff0ca1f23dbd64913ede8", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t13.inf", 
		"Mode=HTTP", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"niikhdgajlphfehepabhhblakbdgeefj\",\"brand\":\"RXQR\",\"cohort\":\"1:1uh3:\",\"cohortname\":\"Auto Main Cohort.\",\"enabled\":true,\"installdate\":6132,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.441f77e6a12317b6133da43ae04862b7d6c848c5789540fc667a227f254dd755\"}]},\"ping\":{\"ping_freshness\":\"{c320347d-3312-4c10-b533-9c648defcd77}\",\"rd\":6353},\"updatecheck\":{},\""
		"version\":\"2024.5.24.0\"},{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"RXQR\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{a9d5c788-9748-44b0-b655-aa5f7ec0f463}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"RXQR\",\"cohort\":\"1:1zdx:\",\"cohortname\":\"4.10.2710.0 to Windows (x86/x64)\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\""
		"ping\":{\"ping_freshness\":\"{b9733b4c-e364-4843-ac19-24e898c7e7a6}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"4.10.2710.0\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"RXQR\",\"cohort\":\"1:bm1:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.cd1978742a4afdbaaa15bf712d5c90bef4144caa99024df98f6a9ad58043ae85\"}]},\"ping\":{\"ping_freshness\":\"{9fcc2d1e-3c0a-42fa-b594-7410ce99ca33}\",\"rd\":6353},\""
		"updatecheck\":{},\"version\":\"9.49.1\"},{\"accept_locale\":\"ENUS500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"RXQR\",\"cohort\":\"1:s6f:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.40530dd93ad0a5f406a909a50c9aec82f6be28a61208ef052823ff0b59fd3bdd\"}]},\"ping\":{\"ping_freshness\":\"{34366f38-837f-4118-a3e3-84d602f73678}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"20240404.625479014.14\"},{\""
		"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"RXQR\",\"cohort\":\"1:lwl:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.7c7270ef0b71ec063a98f512831a53690989605dcb0fbf503b95ca5bb4f98b63\"}]},\"ping\":{\"ping_freshness\":\"{19a45d3a-8a51-4485-b868-c1703f381a35}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"448\"},{\"appid\":\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"brand\":\"RXQR\",\"cohort\":\"1:v3l:\",\""
		"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.153e9301be7e862a33e2cab936a0a97e2f8bdf2dae1be516d6fe8a5f184ce028\"}]},\"ping\":{\"ping_freshness\":\"{eb4cb640-fe56-4ab0-8ae2-e394454c224e}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"2024.5.3.1\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"RXQR\",\"cohort\":\"1:j5l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\""
		":{\"package\":[{\"fp\":\"1.fd515ec0dc30d25a09641b8b83729234bc50f4511e35ce17d24fd996252eaace\"}]},\"ping\":{\"ping_freshness\":\"{f42c76a1-4de4-4a2a-a470-0320ea7bb94e}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"RXQR\",\"cohort\":\"1:cux:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.3705656094a72760ea5c7aca9e229b54669c39a219672cfa4d23c3b153fa649c\"}]},\""
		"ping\":{\"ping_freshness\":\"{ce4de553-bce8-489c-9235-2b2baeae5c2a}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"65\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"RXQR\",\"cohort\":\"1:2879:\",\"cohortname\":\"Auto androidlowmem\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.9123eaa5004d617de29fbc6e0208b8ae20faa533fd8ce9060915832f6a1bb799\"}]},\"ping\":{\"ping_freshness\":\"{2c4b7eb3-e7ae-4605-8d62-5e82ab59c5d9}\",\"rd\":6353},"
		"\"updatecheck\":{},\"version\":\"8784\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\"RXQR\",\"cohort\":\"1:10zr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{940a52fb-0d8b-4fb2-a2d5-98f211b1e3f4}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"1.0.7.1652906823\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"RXQR\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\""
		"packages\":{\"package\":[{\"fp\":\"1.3a118962ef814c91f6476bb9f0de58afa63103af6ac1b8729be9b39a86789e96\"}]},\"ping\":{\"ping_freshness\":\"{c8b44808-f0f3-4c0b-b237-2792fab23159}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"1.0.0.15\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"RXQR\",\"cohort\":\"1:18ql:\",\"cohortname\":\"Auto Stage3\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\""
		"1.25f487750f58c4aae4413367893020f37d6ebf63936eaab497584b84e3f3ced2\"}]},\"ping\":{\"ping_freshness\":\"{bac5ab4e-6ffa-46fb-a0e7-6b4b01fd8899}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"965\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"RXQR\",\"cohort\":\"1:ofl:\",\"cohortname\":\"stable64\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\""
		"ping_freshness\":\"{256be130-72ea-48b9-b748-5b9e26a319e8}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"RXQR\",\"cohort\":\"1:ut9/1a0f/2c99:2c9f@0.5\",\"cohortname\":\"Rollout\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.d1f1a6954babb7330ef005df1b89dcdcb3d163ad1fed7a6800032ebb5d3b8b70\"}]},\"ping\":{\"ping_freshness\":\"{80c51fed-e52f-4b9d-bf89-cd7d01f69364}\",\"rd\""
		":6353},\"updatecheck\":{},\"version\":\"2024.4.15.1148\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"RXQR\",\"cohort\":\"1:w0x:\",\"cohortname\":\"All users\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.545666a4efd056351597bb386aea1368105ededc976ed5650d8682daab9f37ff\"}]},\"ping\":{\"ping_freshness\":\"{5f3f3ffa-b713-42c4-bab2-77abf83da0a1}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"3\"},{\"appid\":\""
		"cocncanleafgejenidihemfflagifjic\",\"brand\":\"RXQR\",\"cohort\":\"1:13hr:\",\"cohortname\":\"Everyone Else\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.2b38451531e26ec7b046a0b16da068f362c78c09df795329402ccf77914c18b4\"}]},\"ping\":{\"ping_freshness\":\"{6ac71e04-9530-4b5c-8bb4-6ebaa6c5495b}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"2023.3.30.1305\"},{\"appid\":\"jflhchccmppkfebkiaminageehmchikm\",\"brand\":\"RXQR\",\"cohort\":\"1:26yf:\","
		"\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6153,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.362e7772d3f33014584c77d153634dd0b942e68a7f4b089a8c32c9f1a1dac51a\"}]},\"ping\":{\"ping_freshness\":\"{7043b4a7-1b9f-473b-9429-74d21d525920}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"2024.5.23.3\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"RXQR\",\"cohort\":\"1:w59:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\""
		"packages\":{\"package\":[{\"fp\":\"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}]},\"ping\":{\"ping_freshness\":\"{ea44c21f-51e0-4276-b336-169511767d0b}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"2020.11.2.164946\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"RXQR\",\"cohort\":\"1:s7x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\""
		"1.888ebbd183d017421d0f23a0a1ea9eaedffefd772878d86c67536c138ef62ada\"}]},\"ping\":{\"ping_freshness\":\"{188a7439-b192-448a-b069-002d2800cb62}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"3030\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"RXQR\",\"cohort\":\"1:wvr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.c52c62a7c50daf7d3f73ec16977cd4b0ea401710807d5dbe3850941dd1b73a70\"}]},\"ping\":{\""
		"ping_freshness\":\"{a5e1ac7a-8e6a-480c-8fe7-c3f88fd70464}\",\"rd\":6353},\"updatecheck\":{},\"version\":\"120.0.6050.0\"},{\"appid\":\"gonpemdgkjcecdgbnaabipppbmgfggbe\",\"brand\":\"RXQR\",\"cohort\":\"1:z1x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.046a7153ace40b4c1fcb2423ffdd0bda38820d2bade6aa5ab6929fe80e4acea3\"}]},\"ping\":{\"ping_freshness\":\"{736471ee-db31-4b51-a6e9-a3eb1192c09d}\",\"rd\":6353},\"updatecheck\":"
		"{},\"version\":\"2024.5.21.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":true,\"hw\":{\"avx\":true,\"physmemory\":32,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.17763.5696\"},\"prodversion\":\"125.0.6422.78\",\"protocol\":\"3.1\",\"requestid\":\"{7bf3ab4b-ec8b-4501-8638-8723b71fd60a}\",\"sessionid\":\""
		"{f5824f3b-4713-45da-84fe-59c8376eba29}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"ChromiumUpdater\",\"updatepolicy\":-1,\"version\":\"127.0.6490.0\"},\"updaterversion\":\"125.0.6422.78\"}}", 
		LAST);

	lr_think_time(20);

	web_custom_request("json_3", 
		"URL=http://update.googleapis.com/service/update2/json", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t14.inf", 
		"Mode=HTTP", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"RXQR\",\"cohort\":\"1:2879:\",\"cohortname\":\"Auto androidlowmem\",\"enabled\":true,\"event\":[{\"download_time_ms\":16294,\"downloaded\":1891,\"downloader\":\"bits\",\"eventresult\":1,\"eventtype\":14,\"nextversion\":\"8785\",\"previousversion\":\"8784\",\"total\":1891,\"url\":\"http://edgedl.me.gvt1.com/edgedl/diffgen-puffin/"
		"hfnkpimlhhgieaddgfemjhofmfblmnib/1.7b206f0a6346ed92d14241d12cbe70fc762e1f1c9485fffa5b90aa45b8783d1d/1.9123eaa5004d617de29fbc6e0208b8ae20faa533fd8ce9060915832f6a1bb799/89018ce9a54e5886179e32dfeb73ea2fd1568945154dc0e3f35c1a08ac92dd55.puff\"},{\"diffresult\":1,\"eventresult\":1,\"eventtype\":3,\"nextfp\":\"1.7b206f0a6346ed92d14241d12cbe70fc762e1f1c9485fffa5b90aa45b8783d1d\",\"nextversion\":\"8785\",\"previousfp\":\"1.9123eaa5004d617de29fbc6e0208b8ae20faa533fd8ce9060915832f6a1bb799\",\""
		"previousversion\":\"8784\"}],\"installdate\":6077,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.7b206f0a6346ed92d14241d12cbe70fc762e1f1c9485fffa5b90aa45b8783d1d\"}]},\"version\":\"8785\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":true,\"hw\":{\"avx\":true,\"physmemory\":32,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\""
		"10.0.17763.5696\"},\"prodversion\":\"125.0.6422.78\",\"protocol\":\"3.1\",\"requestid\":\"{ec054d54-b8b3-492b-96ed-9dfa1eb40051}\",\"sessionid\":\"{f5824f3b-4713-45da-84fe-59c8376eba29}\",\"updaterversion\":\"125.0.6422.78\"}}", 
		LAST);

	lr_think_time(45);

	lr_start_transaction("ParBank_RaiseTicket_02_EnterDetail_SendToCustSpt");

	web_submit_data("contact.htm", 
		"Action=https://parabank.parasoft.com/parabank/contact.htm", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=https://parabank.parasoft.com/parabank/contact.htm;jsessionid=70C095D2641C8FE0916F16E37DB2EB78", 
		"Snapshot=t15.inf", 
		"Mode=HTTP", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=name", "Value=lavishjassal1", ENDITEM, 
		"Name=email", "Value=lavish12324@gmail.com", ENDITEM, 
		"Name=phone", "Value=73559819010", ENDITEM, 
		"Name=message", "Value=website crashing intermittently", ENDITEM, 
		LAST);

	lr_end_transaction("ParBank_RaiseTicket_02_EnterDetail_SendToCustSpt",LR_AUTO);

	return 0;
}